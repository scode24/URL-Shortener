package com.surlgenerator.code.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.surlgenerator.code.exceptions.SurlDecodeException;
import com.surlgenerator.code.exceptions.SurlEncodeException;
import com.surlgenerator.code.service.SurlGeneratorService;

@RestController
@CrossOrigin
public class SurlGeneratorController {
	
	@Autowired
	private SurlGeneratorService surlGeneratorService;
	
	@PostMapping("/generateShortUrl")
	public Map<String, String> generateShortUrl(@RequestParam("url") String url) throws SurlEncodeException{
		Map<String, String> response = new HashMap<>();
		response.put("surl", surlGeneratorService.encode(url));
		return response;
	}
	
	@PostMapping("/getUrlFromSurl")
	public Map<String, String> getUrlFromSurlgetUrlFromSurl(@RequestParam("surl") String surl) throws SurlDecodeException{
		Map<String, String> response = new HashMap<>();
		response.put("url", surlGeneratorService.decode(surl));
		return response;
	}
	
	@GetMapping("/getAllSurls")
	public List<Map<String, String>> getAllSurls(){
		return surlGeneratorService.getAllSurls();
	}

}
