package com.surlgenerator.code.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.surlgenerator.code.exceptions.SurlDecodeException;
import com.surlgenerator.code.exceptions.SurlEncodeException;

@ControllerAdvice
public class SurlGeneratorExceptionHandler extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(value=SurlEncodeException.class)
	public ResponseEntity<Map<String, String>> handleEncodeException(SurlEncodeException encodeException){
		Map<String, String> response = new HashMap<>();
		response.put("message", encodeException.getMessage());
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST); 
	}
	
	@ExceptionHandler(value=SurlDecodeException.class)
	public ResponseEntity<Map<String, String>> handleDecodeException(SurlDecodeException decodeException){
		Map<String, String> response = new HashMap<>();
		response.put("message", decodeException.getMessage());
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST); 
	}

}
