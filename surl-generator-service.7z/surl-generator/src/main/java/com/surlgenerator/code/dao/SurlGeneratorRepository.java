/**
 * 
 */
package com.surlgenerator.code.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.surlgenerator.code.models.UrlRecord;

/**
 * @author soumyabs
 *
 */
public interface SurlGeneratorRepository extends JpaRepository<UrlRecord, Long> {

	@Query("select u from UrlRecord u where url = :url")
	UrlRecord findByUrl(String url);

	@Query("select u from UrlRecord u where surl = :surl")
	UrlRecord findBySurl(String surl);
	
	@Query("select u from UrlRecord u order by u.createTimestamp desc")
	List<UrlRecord> findAllSurls();

	@Query("select u from UrlRecord u where u.getDaysDifference() > :days")
	UrlRecord clearUnusedRecords(int days);

}
