package com.surlgenerator.code.exceptions;

public class SurlDecodeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public SurlDecodeException(String msg) {
		super(msg);
	}

}
