package com.surlgenerator.code.exceptions;

public class SurlEncodeException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SurlEncodeException(String msg) {
		super(msg);
	}
}
