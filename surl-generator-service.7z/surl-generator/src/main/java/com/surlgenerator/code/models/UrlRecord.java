package com.surlgenerator.code.models;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.concurrent.TimeUnit;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class UrlRecord {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column
	private String url;
	
	@Column
	private String surl;
	
	@Column
	private Timestamp createTimestamp;
	
	public UrlRecord() {
		
	}
	
	public UrlRecord(String url, String surl, Timestamp createTimestamp) {
		this.url = url;
		this.surl = surl;
		this.createTimestamp = createTimestamp;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getSurl() {
		return surl;
	}

	public void setSurl(String surl) {
		this.surl = surl;
	}

	public Timestamp getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
	}
	
	public long getDaysDifference() {
        // Convert Timestamp to Date
        Date date1 = new Date(getCreateTimestamp().getTime());
        Date date2 = new Date(Timestamp.from(Instant.now()).getTime());

        // Calculate the difference in milliseconds
        long timeDifferenceMillis = date2.getTime() - date1.getTime();

        // Calculate the difference in days
        long daysDifference = TimeUnit.DAYS.convert(timeDifferenceMillis, TimeUnit.MILLISECONDS);

        return daysDifference;
    }

	@Override
	public String toString() {
		return "UrlRecord [url=" + url + ", surl=" + surl + ", createTimestamp=" + createTimestamp + "]";
	}
}
