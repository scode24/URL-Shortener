package com.surlgenerator.code.scheduler;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.surlgenerator.code.dao.SurlGeneratorRepository;
import com.surlgenerator.code.models.UrlRecord;

@Component
public class SurlGeneratorScheduler {
	
	private static final Logger logger = Logger.getLogger(SurlGeneratorScheduler.class.getName());
	
	@Autowired
	SurlGeneratorRepository surlGeneratorRepository;
	
	@Value("${unusedRecordCleanupAfterDays}")
	private String unusedRecordCleanupAfterDays;
	
	@Scheduled(cron = "0 0 0 * * *")
	public void clearUnusedUrlRecords() {
	    UrlRecord urlRecord = surlGeneratorRepository.clearUnusedRecords(Integer.parseInt(unusedRecordCleanupAfterDays));
	    logger.info("Cleaning : "+urlRecord);
	    surlGeneratorRepository.delete(urlRecord);
	}

}
