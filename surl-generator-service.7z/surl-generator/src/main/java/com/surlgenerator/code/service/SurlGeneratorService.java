package com.surlgenerator.code.service;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.surlgenerator.code.dao.SurlGeneratorRepository;
import com.surlgenerator.code.exceptions.SurlDecodeException;
import com.surlgenerator.code.exceptions.SurlEncodeException;
import com.surlgenerator.code.models.UrlRecord;

@Service
public class SurlGeneratorService {

	private static final String URL_DATA_IS_ALREADY_PRESENT_IN_RECORD = "URL data is already present in record";
	private static final String URL_DATA_IS_NOT_ALREADY_PRESENT_IN_RECORD = "URL data is not already present in record";
	
	@Value("${baseUiPath}")
	private String baseUiPath;
	
	@Autowired
	SurlGeneratorRepository surlGeneratorRepository;

	public String encode(String url) throws SurlEncodeException {

		if (surlGeneratorRepository.findByUrl(url) != null) {
			throw new SurlEncodeException(URL_DATA_IS_ALREADY_PRESENT_IN_RECORD);
		}

		List<UrlRecord> UrlRecordList = surlGeneratorRepository.findAll();

		Map<String, String> map = UrlRecordList.stream().collect(Collectors.toMap(d -> d.getSurl(), d -> d.getUrl()));

		String surl = "";
		Random r = new Random();

		while (!map.containsKey(surl) && surl.isEmpty()) {
			char c = (char) (r.nextInt(26) + 'A');
			surl += c;
		}
		
		surl = baseUiPath+"/"+surl;

		surlGeneratorRepository.save(new UrlRecord(url, surl, Timestamp.from(Instant.now())));

		return surl;
	}
	
	public String decode(String surl) throws SurlDecodeException {
		
		UrlRecord urlRecord = surlGeneratorRepository.findBySurl(surl);
		
		if (urlRecord == null) {
			throw new SurlDecodeException(URL_DATA_IS_NOT_ALREADY_PRESENT_IN_RECORD);
		}
		
		urlRecord.setCreateTimestamp(Timestamp.from(Instant.now()));
		surlGeneratorRepository.save(urlRecord);
		
		return urlRecord.getUrl();
	}

	public List<Map<String, String>> getAllSurls() {
		
		List<UrlRecord> urlRecords = surlGeneratorRepository.findAllSurls();
		List<Map<String, String>> records = new ArrayList<>();
		
		for(UrlRecord urlRecord: urlRecords) {
			Map<String, String> map = new HashMap<String, String>();
			map.put("surl", urlRecord.getSurl());
			map.put("url", urlRecord.getUrl());
			records.add(map);
		}
		
		return records;
	}

}
