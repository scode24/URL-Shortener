package com.urlgenerator.code;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurlGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
